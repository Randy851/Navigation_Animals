package com.example.animalesrandal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Omnivoros extends AppCompatActivity {

    private ListView lvOmnivoros;
    private ImageView imgFoto;
    private TextView txtNombre;
    private TextView txtDescripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_omnivoros);

        lvOmnivoros=findViewById(R.id.lvOmnivoros);
        imgFoto=findViewById(R.id.imgFoto);
        txtNombre=findViewById(R.id.txtNombre);
        txtDescripcion=findViewById(R.id.txtDescripcion);

        String[] animales = new String[]{"Oso","Mapache","Conejo"};
        ArrayAdapter<String> adpAnimales = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,animales);
        lvOmnivoros.setAdapter(adpAnimales);

        lvOmnivoros.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){

                    case 0:

                        txtNombre.setText("Oso");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.oso);
                        txtDescripcion.setText("Los osos o úrsidos son una familia de mamíferos omnívoros.Son animales de gran tamaño, generalmente omnívoros ya que, a pesar de su temible dentadura, comen frutos, raíces e insectos, además de carne.\n" +
                                "Sin embargo, el oso polar, debido a la escasez de otras fuentes de alimento, se alimenta casi únicamente de carne.");

                        break;

                    case 1:
                        txtNombre.setText("Mapache");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.mapache);
                        txtDescripcion.setText("Sin embargo, el oso polar, debido a la escasez de otras fuentes de alimento, se alimenta casi únicamente de carne.\n" +
                                "u osos lavadores. Son propios de América.");


                        break;

                    case 2:
                        txtNombre.setText("Conejo");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.conejo);
                        txtDescripcion.setText("El conejo común o conejo europeo es una especie de mamífero lagomorfo de la familia Leporidae, y el único miembro actual del género Oryctolagus. Mide hasta 50 cm y pesa hasta 2.5 kilos.\n" +
                                "Ha sido introducido en varios continentes y es la especie que se utiliza en la cocina y en la cunicultura.");

                        break;
                }
            }
        });
    }
}
