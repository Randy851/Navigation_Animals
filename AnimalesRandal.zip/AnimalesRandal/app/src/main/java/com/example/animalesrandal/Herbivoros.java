package com.example.animalesrandal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Herbivoros extends AppCompatActivity {

    private ListView lvHerbivoros;
    private ImageView imgFoto;
    private TextView txtNombre;
    private TextView txtDescripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_herbivoros);

        lvHerbivoros=findViewById(R.id.lvHerbivoros);
        imgFoto=findViewById(R.id.imgFoto);
        txtNombre=findViewById(R.id.txtNombre);
        txtDescripcion=findViewById(R.id.txtDescripcion);

        String[] animales = new String[]{"Canguro","Koala","Conejo"};
        ArrayAdapter<String> adpAnimales = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,animales);
        lvHerbivoros.setAdapter(adpAnimales);

        lvHerbivoros.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch(position){

                    case 0:

                        txtNombre.setText("Canguro");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.canguro);
                        txtDescripcion.setText("El término canguro es el nombre común que se utiliza para designar a las especies de mayor tamaño de la subfamilia Macropodinae\n" +
                                "como el término ualabí se utiliza para denominar a las de menor tamaño.");

                        break;

                    case 1:
                        txtNombre.setText("Koala");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.koala);
                        txtDescripcion.setText("El koala es una especie de marsupial diprotodonto de la familia Phascolarctidae, endémico de Australia.\n" +
                                "\n" +
                                "Es el único representante existente de la familia Phascolarctidae y sus parientes vivos más cercanos son los wombats.");


                        break;

                    case 2:
                        txtNombre.setText("Conejo");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.conejo);
                        txtDescripcion.setText("El conejo común o conejo europeo es una especie de mamífero lagomorfo de la familia Leporidae, y el único miembro actual del género Oryctolagus.\n" +
                                "Mide hasta 50 cm y pesa hasta 2.5 kilos. Ha sido introducido en varios continentes y es la especie que se utiliza en la cocina y en la cunicultura.");


                        break;
                }
            }
        });
    }
}
