package com.example.animalesrandal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Carnivoros extends AppCompatActivity {

    private ListView lvCarnivoros;
    private ImageView imgFoto;
    private TextView txtNombre;
    private TextView txtDescripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carnivoros);

        lvCarnivoros=findViewById(R.id.lvCarnivoros);
        imgFoto=findViewById(R.id.imgFoto);
        txtNombre=findViewById(R.id.txtNombre);
        txtDescripcion=findViewById(R.id.txtDescripcion);

        String[] animales = new String[]{"Jaguar","Lobo","Tiburon"};
        ArrayAdapter<String> adpAnimales = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,animales);
        lvCarnivoros.setAdapter(adpAnimales);

        lvCarnivoros.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){

                    case 0:
                        txtNombre.setText("Jaguar");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.jaguar);
                        txtDescripcion.setText("El jaguar, yaguar o yaguareté es un carnívoro félido de la subfamilia de los Panterinos y género Panthera.\nEs la única de las cinco especies actuales de este género que se encuentra en América. También es el mayor félido de América y el tercero del mundo, después del tigre y el león.");

                        break;

                    case 1:
                        txtNombre.setText("Lobo");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.lobo);
                        txtDescripcion.setText("El lobo es una especie de mamífero placentario del orden de los carnívoros\nEl perro doméstico se considera miembro de la misma especie según distintos indicios, la secuencia del ADN y otros estudios genéticos.");


                        break;

                    case 2:
                        txtNombre.setText("Tiburon");
                        imgFoto.setVisibility(View.VISIBLE);
                        imgFoto.setImageResource(R.drawable.tiburon);
                        txtDescripcion.setText("Los selaquimorfos o selacimorfos son un superorden de condrictios conocidos comúnmente con el nombre de tiburones o escualos.\nAlgunos grandes escualos, como el tiburón blanco y el toro, son conocidos a veces con el nombre de jaquetones. Se caracterizan por ser grandes depredadores.");

                        break;
                }
            }
        });

    }
}
