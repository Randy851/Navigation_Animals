package com.example.animalesrandal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ListView lvClasificación;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvClasificación=findViewById(R.id.lvClasificacion);

        String[] animales = new String[]{"Carnívoros","Herbívoros","Omnívoros"};
        ArrayAdapter<String> adpAnimales = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,animales);
        lvClasificación.setAdapter(adpAnimales);

        lvClasificación.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch(position){

                    case 0:
                        Intent c=new Intent(MainActivity.this,Carnivoros.class);
                        startActivity(c);
                        break;

                    case 1:
                        Intent h=new Intent(MainActivity.this,Herbivoros.class);
                        startActivity(h);
                        break;

                    case 2:
                        Intent o=new Intent(MainActivity.this,Omnivoros.class);
                        startActivity(o);
                        break;
                }

            }
        });
    }
}
